A Pen created at CodePen.io. You can find this one at https://codepen.io/msillah25/pen/jdweqw.

 mariama's travelogue is a simple webpage that explains the her travel experience  